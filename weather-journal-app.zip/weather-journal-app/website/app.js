/* Global Variables */

const baseurl = 'https://api.openweathermap.org/data/2.5/weather?units=metric&zip=';
const ApiKey = ',us&appid=ebd53c3c5e6d563a9861390ef9b8a822' ;

const unit = 'metric';
const zipCode = document.getElementById('zip').value;

const urll ='https://api.openweathermap.org/data/2.5/weather?zip=94040,us&appid=ebd53c3c5e6d563a9861390ef9b8a822';
// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();


// Event listener to add function to existing HTML DOM element 

document.getElementById('generate').addEventListener('click' , perform);
// Function called by event listener

function perform(e){
    e.preventDefault();
    // getweather(baseurl,zipCode,ApiKey)
    const feelings =document.getElementById('feelings').value;
    const zipCode = document.getElementById('zip').value;
    getweather(baseurl,zipCode,ApiKey)
    .then(function(data){
        myData('/addData' , {
            date:newDate,
            temp:data.main.temp,
            content:feelings ,
        })
    }).then(function (newData) {
        Showdata();
    });
   
}
//function to get API data
const  getweather = async (url,zip,key) =>{
    const res = await fetch(url+zip+key);

    try{
        const data = await res.json()
        console.log(data);
        return data;
    } catch(error){
        console.log("error " , error);
    }
};
//  Function to POST data 
const myData = async ( url = '', data = {})=>{
    console.log(data);
    
      const response = await fetch(url, {
      method: 'POST', 
      credentials: 'same-origin',
      headers: {
          'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),   
    });
      try {
        const newData = await response.json();
        return newData;
      }catch(error) {
      console.log("error", error);
      }
  };

 //Function to GET Project Data 
 const Showdata = async ()=>{
    const request =await fetch('/alldata');
    try{
      const allData = await request.json();
      console.log("all data is : " + allData);
      document.getElementById('content').innerHTML=`Felling : ${allData.content}`;
      document.getElementById('temp').innerHTML=`Temp : ${allData.temp}`;
      document.getElementById('date').innerHTML=`Date : ${allData.date}`;

    } catch(error){
        console.log('error' , error);
    }
};